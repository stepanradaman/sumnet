﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ESRI.ArcGIS.Geometry;
using ESRI.ArcGIS.Carto;
using ESRI.ArcGIS.ArcMapUI;
using ESRI.ArcGIS.esriSystem;
using ESRI.ArcGIS.Geodatabase;
using ESRI.ArcGIS.CatalogUI;
using ESRI.ArcGIS.Catalog;
using ESRI.ArcGIS.DataSourcesFile;


namespace SumNet
{
    /// <summary>
    /// Designer class of the dockable window add-in. It contains user interfaces that
    /// make up the dockable window.
    /// </summary>
    public partial class SumNetWindow : UserControl
    {
        public SumNetWindow(object hook)
        {
            InitializeComponent();
            this.Hook = hook;
            comboBox1.SelectedIndex = 0;
        }

        /// <summary>
        /// Host object of the dockable window
        /// </summary>
        private object Hook
        {
            get;
            set;
        }

        /// <summary>
        /// Implementation class of the dockable window add-in. It is responsible for 
        /// creating and disposing the user interface class of the dockable window.
        /// </summary>
        public class AddinImpl : ESRI.ArcGIS.Desktop.AddIns.DockableWindow
        {
            private SumNetWindow m_windowUI;

            public AddinImpl()
            {
            }

            protected override IntPtr OnCreateChild()
            {
                m_windowUI = new SumNetWindow(this.Hook);
                return m_windowUI.Handle;
            }

            protected override void Dispose(bool disposing)
            {
                if (m_windowUI != null)
                    m_windowUI.Dispose(disposing);

                base.Dispose(disposing);
            }

        }

        //create
        private void button1_Click(object sender, EventArgs e)
        {
            IMxDocument mxd = ArcMap.Application.Document as ESRI.ArcGIS.ArcMapUI.IMxDocument;
            IMap map = mxd.FocusMap;
            IActiveView pActiveView;

            IWorkspace ws;
            IFields fields;
            IFieldsEdit fieldsEdit;
            IField field;
            IFieldEdit fieldEdit;
            IGeometryDefEdit geomDefEdit;
            IFeatureClass fc;
            IGxDialog gxDialog;

            IEnumFeature pEnumFeat = map.FeatureSelection as IEnumFeature;
            pEnumFeat.Reset();
            IFeature pFeat = pEnumFeat.Next();

            if (pFeat == null)
            {
                MessageBox.Show("Select Features");
                System.Runtime.InteropServices.Marshal.ReleaseComObject(pEnumFeat);
                return;
            }

            //File location
            gxDialog = new GxDialogClass();
            gxDialog.ObjectFilter = new GxFilterPolygonFeatureClassesClass();

            // return if cancelled
            if (!gxDialog.DoModalSave(0)) return;

            if (gxDialog.FinalLocation is IGxDatabase)
            {
                // if the user selected a workspace
                ws = ((IGxDatabase)gxDialog.FinalLocation).Workspace;
            }
            else if (gxDialog.FinalLocation is IGxDataset)
            {
                // if the user selected a dataset
                ws = ((IGxDataset)gxDialog.FinalLocation).Dataset.Workspace;
            }
            else if (gxDialog.FinalLocation is IGxFolder)
            {
                // create a shapefile workspace factory
                IWorkspaceFactory wsFact;
                IName wsName;

                wsFact = new ShapefileWorkspaceFactoryClass();
                wsName = (IName)wsFact.Create(System.IO.Path.GetDirectoryName(gxDialog.FinalLocation.FullName),
                    System.IO.Path.GetFileName(gxDialog.FinalLocation.FullName), null, 0);
                ws = (IWorkspace)wsName.Open();
            }
            else
            {
                // unsupported final location
                throw new ApplicationException(string.Format("Unsupported final location category: {0}",
                    gxDialog.FinalLocation.Category));
            }

            // check if the user-specified name already exists
            if (((IWorkspace2)ws).NameExists[esriDatasetType.esriDTFeatureClass, gxDialog.Name])
            {
                IEnumDataset enumDS;
                IDataset ds;

                if (MessageBox.Show(string.Format("{0}: Already exists. Do you want to overwrite it?", gxDialog.Name),
                    "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.No) return;

                enumDS = ws.Datasets[esriDatasetType.esriDTFeatureClass];
                while ((ds = enumDS.Next()) != null)
                {
                    if ((ds.Name + (gxDialog.FinalLocation is IGxFolder ? ".shp" : "")).ToUpper() == gxDialog.Name.ToUpper())
                    {
                        if (ds.CanDelete())
                        {
                            ds.Delete();
                        }
                        else
                        {
                            throw new ApplicationException(string.Format("{0}: Cannot delete", gxDialog.Name));
                        }
                    }
                }
            }

            // create required fields
            fields = new FieldsClass();
            fieldsEdit = (IFieldsEdit)fields;

            // create an OID field
            field = new FieldClass();
            fieldEdit = (IFieldEdit)field;
            fieldEdit.Name_2 = "ObjectID";
            fieldEdit.Type_2 = esriFieldType.esriFieldTypeOID;
            fieldEdit.Required_2 = true;
            fieldEdit.IsNullable_2 = false;

            // add the OID field
            fieldsEdit.AddField(field);

            //Create geometry field  
            IGeometryDef geomDef = new GeometryDefClass();
            IGeometryDefEdit geomeDefEdit = (IGeometryDefEdit)geomDef;
            geomeDefEdit.GeometryType_2 = esriGeometryType.esriGeometryPolygon;
            ISpatialReferenceFactory spatialReferenceFactory = new SpatialReferenceEnvironment();

            ISpatialReference spatialReference = map.SpatialReference;
            //ISpatialReference spatialReference = spatialReferenceFactory.CreateProjectedCoordinateSystem((int)esriSRProjCSType.esriSRProjCS_NAD1983UTM_20N);
            //ISpatialReference spatialReference = spatialReferenceFactory.CreateGeographicCoordinateSystem((int)esriSRGeoCSType.esriSRGeoCS_WGS1984);

            ISpatialReferenceResolution spatialReferenceResolution = (ISpatialReferenceResolution)spatialReference;
            spatialReferenceResolution.ConstructFromHorizon();
            ISpatialReferenceTolerance spatialReferenceTolerance = (ISpatialReferenceTolerance)spatialReference;
            spatialReferenceTolerance.SetDefaultXYTolerance();
            geomeDefEdit.SpatialReference_2 = spatialReference;

            // create a geometry field
            field = new FieldClass();
            fieldEdit = (IFieldEdit)field;
            fieldEdit.Name_2 = "Shape";
            fieldEdit.Type_2 = esriFieldType.esriFieldTypeGeometry;
            fieldEdit.GeometryDef_2 = geomDef;
            fieldEdit.Required_2 = true;
            fieldEdit.IsNullable_2 = false;

            // add the geometry field
            fieldsEdit.AddField(field);

            // create a new feature class
            fc = ((IFeatureWorkspace)ws).CreateFeatureClass(gxDialog.Name, fields, null, null, esriFeatureType.esriFTSimple, "Shape", "");

            // add to Project
            IWorkspaceFactory wsf = new ESRI.ArcGIS.DataSourcesFile.ShapefileWorkspaceFactory();
            IFeatureWorkspace fws = ws as ESRI.ArcGIS.Geodatabase.IFeatureWorkspace;
            IFeatureClass fcls = fws.OpenFeatureClass(gxDialog.Name + ".shp");
            IFeatureLayer lay = new ESRI.ArcGIS.Carto.FeatureLayerClass();
            lay.FeatureClass = fcls;
            lay.Name = fcls.AliasName;
            map.AddLayer(lay);


            //determine box of selected features
            pEnumFeat.Reset();
            IEnvelope pEnvelope = new EnvelopeClass();
            if (pFeat == null)
            {
                MessageBox.Show("Select Features");
                System.Runtime.InteropServices.Marshal.ReleaseComObject(pEnumFeat);
                return;
            }

            while (pFeat != null)
            {
                pEnvelope.Union(pFeat.Shape.Envelope);
                pFeat = pEnumFeat.Next();
            }

            float expandxy = float.Parse(textBox3.Text);

            pEnvelope.Expand(1.0 + expandxy, 1.0 + expandxy, true);

            float width = Math.Abs(float.Parse(pEnvelope.XMax.ToString()) - float.Parse(pEnvelope.XMin.ToString()));
            float height = Math.Abs(float.Parse(pEnvelope.YMax.ToString()) - float.Parse(pEnvelope.YMin.ToString()));

            //add polygon
            int xtext = int.Parse(textBox1.Text);
            int ytext = int.Parse(textBox2.Text);
            int x = 1;
            int y = 1;

            if (xtext < 1)
            {
                x = 1;
            }
            else
            {
                x = xtext;
            }

            if (ytext < 1)
            {
                y = 1;
            }
            else
            {
                y = ytext;
            }


            float nullx = float.Parse(pEnvelope.LowerLeft.X.ToString());
            float nully = float.Parse(pEnvelope.LowerLeft.Y.ToString());

            //rectangles
            if (comboBox1.SelectedIndex == 0)
            {
                for (int i = 0; i < x; i++)
                {
                    for (int j = 0; j < y; j++)
                    {
                        float nullxcorrected = nullx + ((width / x) * i);
                        float nullycorrected = nully + ((height / y) * j);

                        IFeature feature = fc.CreateFeature();
                        IPolygon polygon = new PolygonClass();
                        IPointCollection pColl = (IPointCollection)polygon;
                        IPoint point = new PointClass();
                        object missing = Type.Missing;
                        int fieldcount = fc.FindField("Id");
                        feature.set_Value(fieldcount, 1739);

                        point.PutCoords(nullxcorrected, nullycorrected);
                        pColl.AddPoint(point, ref missing, ref missing);

                        point = new PointClass();
                        point.PutCoords(nullxcorrected, nullycorrected + (height / y));
                        pColl.AddPoint(point, ref missing, ref missing);

                        point = new PointClass();
                        point.PutCoords(nullxcorrected + (width / x), nullycorrected + (height / y));
                        pColl.AddPoint(point, ref missing, ref missing);

                        point = new PointClass();
                        point.PutCoords(nullxcorrected + (width / x), nullycorrected);
                        pColl.AddPoint(point, ref missing, ref missing);

                        polygon.Close();
                        polygon.SpatialReference = spatialReference;
                        feature.Shape = polygon;
                        feature.Store();
                    }
                }
            }

            //squares
            if (comboBox1.SelectedIndex == 1)
            {
                float side;
                float fdeltaside;
                decimal iideltaside;
                int ideltaside;
                int additems;
                int a;


                if (width > height)
                {
                    side = height;
                    fdeltaside = (width - height) / (height / y);
                    iideltaside = Math.Round((decimal)fdeltaside, 0, MidpointRounding.AwayFromZero);
                    ideltaside = (int)fdeltaside;

                    if ((fdeltaside - ideltaside) >= 0)
                    {
                        additems = ideltaside + 1;
                    }
                    else
                    {
                        additems = ideltaside;
                    }

                    x = y + additems;
                    y = y;
                    a = y;

                }
                else
                {
                    side = width;
                    fdeltaside = (height - width) / (width / x);
                    iideltaside = Math.Round((decimal)fdeltaside, 0, MidpointRounding.AwayFromZero);
                    ideltaside = (int)fdeltaside;
                    if ((fdeltaside - ideltaside) >= 0)
                    {
                        additems = ideltaside + 1;
                    }
                    else
                    {
                        additems = ideltaside;
                    }

                    x = x;
                    y = x + additems;
                    a = x;
                }


                for (int i = 0; i < x; i++)
                {
                    for (int j = 0; j < y; j++)
                    {
                        float nullxcorrected = nullx + ((side / a) * i);
                        float nullycorrected = nully + ((side / a) * j);

                        IFeature feature = fc.CreateFeature();
                        IPolygon polygon = new PolygonClass();
                        IPointCollection pColl = (IPointCollection)polygon;
                        IPoint point = new PointClass();
                        object missing = Type.Missing;
                        int fieldcount = fc.FindField("Id");
                        feature.set_Value(fieldcount, 1739);

                        point.PutCoords(nullxcorrected, nullycorrected);
                        pColl.AddPoint(point, ref missing, ref missing);

                        point = new PointClass();
                        point.PutCoords(nullxcorrected, nullycorrected + (side / a));
                        pColl.AddPoint(point, ref missing, ref missing);

                        point = new PointClass();
                        point.PutCoords(nullxcorrected + (side / a), nullycorrected + (side / a));
                        pColl.AddPoint(point, ref missing, ref missing);

                        point = new PointClass();
                        point.PutCoords(nullxcorrected + (side / a), nullycorrected);
                        pColl.AddPoint(point, ref missing, ref missing);

                        polygon.Close();
                        polygon.SpatialReference = spatialReference;
                        feature.Shape = polygon;
                        feature.Store();
                    }
                }
            }

            //circles
            if (comboBox1.SelectedIndex == 2)
            {
                float side;
                float fdeltaside;
                decimal iideltaside;
                int ideltaside;
                int additems;
                int a;
                int isegments = int.Parse(textBox4.Text);
                int segments;

                if (isegments < 1)
                {
                    segments = 1;
                }
                else
                {
                    segments = isegments;
                }


                if (width > height)
                {
                    side = height;
                    fdeltaside = (width - height) / (height / y);
                    iideltaside = Math.Round((decimal)fdeltaside, 0, MidpointRounding.AwayFromZero);
                    ideltaside = (int)fdeltaside;

                    if ((fdeltaside - ideltaside) >= 0)
                    {
                        additems = ideltaside + 1;
                    }
                    else
                    {
                        additems = ideltaside;
                    }

                    x = y + additems;
                    y = y;
                    a = y;

                }
                else
                {
                    side = width;
                    fdeltaside = (height - width) / (width / x);
                    iideltaside = Math.Round((decimal)fdeltaside, 0, MidpointRounding.AwayFromZero);
                    ideltaside = (int)fdeltaside;
                    if ((fdeltaside - ideltaside) >= 0)
                    {
                        additems = ideltaside + 1;
                    }
                    else
                    {
                        additems = ideltaside;
                    }

                    x = x;
                    y = x + additems;
                    a = x;
                }


                for (int i = 0; i < x; i++)
                {
                    for (int j = 0; j < y; j++)
                    {

                        float nullxcorrected = nullx + ((side / a) * i) + ((side / a) / 2);
                        float nullycorrected = nully + ((side / a) * j) + ((side / a) / 2);

                        IFeature feature = fc.CreateFeature();
                        IPolygon polygon = new PolygonClass();
                        IPointCollection pColl = (IPointCollection)polygon;
                        IPoint point = new PointClass();
                        object missing = Type.Missing;
                        int fieldcount = fc.FindField("Id");
                        feature.set_Value(fieldcount, 1739);

                        for (int k = 0; k < segments; k++)
                        {
                            double xpoint = Math.Cos(2 * Math.PI * k / segments) * ((side / a) / 2) + nullxcorrected;
                            double ypoint = Math.Sin(2 * Math.PI * k / segments) * ((side / a) / 2) + nullycorrected;

                            point = new PointClass();
                            point.PutCoords(xpoint, ypoint);
                            pColl.AddPoint(point, ref missing, ref missing);
                        }

                        polygon.Close();
                        polygon.SpatialReference = spatialReference;
                        feature.Shape = polygon;
                        feature.Store();
                    }
                }
            }

            pActiveView = mxd.ActiveView;
            pActiveView.Refresh();
        }

        //zoom
        private void button2_Click(object sender, EventArgs e)
        {
            IMxDocument mxd = ArcMap.Application.Document as ESRI.ArcGIS.ArcMapUI.IMxDocument;
            IMap map = mxd.FocusMap;
            IActiveView pActiveView;

            IEnumFeature pEnumFeat = map.FeatureSelection as IEnumFeature;
            pEnumFeat.Reset();
            IFeature pFeat = pEnumFeat.Next();

            if (pFeat == null)
            {
                MessageBox.Show("Select Features");
                System.Runtime.InteropServices.Marshal.ReleaseComObject(pEnumFeat);
                return;
            }

            IEnvelope pEnvelope = new EnvelopeClass();

            while (pFeat != null)
            {
                pEnvelope.Union(pFeat.Shape.Envelope);
                pFeat = pEnumFeat.Next();

            }

            float expandxy = float.Parse(textBox3.Text);
            pEnvelope.Expand(1.0 + expandxy, 1.0 + expandxy, true);
            pActiveView = mxd.ActiveView;
            pActiveView.Extent = pEnvelope;
            pActiveView.Refresh();

            //float wudth = Math.Abs(float.Parse(pEnvelope.XMax.ToString()) - float.Parse(pEnvelope.XMin.ToString()));
            //float height = Math.Abs(float.Parse(pEnvelope.YMax.ToString()) - float.Parse(pEnvelope.YMin.ToString()));
            //MessageBox.Show(pEnvelope.XMax.ToString() + "\n" + pEnvelope.XMin.ToString() + "\n" + pEnvelope.YMax.ToString() + "\n" + pEnvelope.YMin.ToString());
            //MessageBox.Show(wudth.ToString() + "\n" + height.ToString());
        }
    }
}





