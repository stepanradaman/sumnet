﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ESRI.ArcGIS.Framework;
using ESRI.ArcGIS.esriSystem;

namespace SumNet
{
    public class Button1 : ESRI.ArcGIS.Desktop.AddIns.Button
    {
        UID dockableID;
        IDockableWindow dockableWindow1;

        public Button1()
        {
            dockableID = new UIDClass();
            dockableID.Value = ThisAddIn.IDs.SumNetWindow;
        }

        protected override void OnClick()
        {
            dockableWindow1 = ArcMap.DockableWindowManager.GetDockableWindow(dockableID);

            if (dockableWindow1.IsVisible())
            {
                dockableWindow1.Show(false);
            }
            else
            {
                dockableWindow1.Show(true);
            }

            ArcMap.Application.CurrentTool = null;
        }
        protected override void OnUpdate()
        {
            Enabled = ArcMap.Application != null;
        }
    }

}
